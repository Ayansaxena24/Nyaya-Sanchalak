const ROLES_LIST = {
    "Judge": 8888,
    "CourtAdmin": 9999,
}

module.exports = ROLES_LIST